import org.junit.Test;
import static org.junit.Assert.*;

public class SlotMachineAcceptanceTest {
    @Test
    public void shouldAcceptCompleteSlotMachine() {
        //Create an empty machine
        SlotMachine machine = new SlotMachine();
        assertNotNull(machine);
        assertTrue(machine.ok());

        //Add three symbols
        machine.addSymbol("normal", 1, "red");
        assertTrue(machine.ok());
        machine.addSymbol("normal", 2, "blue");
        assertTrue(machine.ok());
        machine.addSymbol("normal", 3, "green");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"},machine.symbols());

        //Add three wheels
        machine.addWheel("normal", 1);
        assertTrue(machine.ok());
        machine.addWheel("normal", 2);
        assertTrue(machine.ok());
        machine.addWheel("normal", 3);
        assertTrue(machine.ok());

        //Set up the three wheels
        machine.spin(new String[]{"red", "blue", "green"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"},machine.configuration());

        //Turn the first wheel one position
        machine.spin(1);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "blue", "green"},machine.configuration());
        assertEquals(2, machine.distinctSymbols());
        assertFalse(machine.isJackpot());

        //Setup with jackpot
        machine.spin(new String[]{"green", "green", "green"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green", "green", "green"},machine.configuration());
        assertEquals(1, machine.distinctSymbols());
        assertTrue(machine.isJackpot());

        //Setup without jackpot
        machine.spin(new String[]{"red", "blue", "green"});
        assertTrue(machine.ok());
        assertFalse(machine.isJackpot());

        //Lock the front wheel and try to turn
        machine.lock(1);
        assertTrue(machine.ok());
        machine.spin(1);
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"},machine.configuration());

        //Unlock the wheel and spin it again
        machine.unlock(1);
        assertTrue(machine.ok());
        machine.spin(1);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "blue", "green"},machine.configuration());

        //Swap the first and third wheel
        machine.swap(1, 3);
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"green", "blue", "blue"},machine.configuration());

        //Delete an existing symbol
        machine.delSymbol("red");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"blue", "green"},machine.symbols());

        //Remove a wheel
        machine.delWheel(1);
        assertTrue(machine.ok());
        assertEquals(2, machine.configuration().length);

        // Try to delete a symbol that does not exist.
        machine.delSymbol("purple");
        assertFalse(machine.ok());
        assertArrayEquals(new String[]{"blue", "green"},machine.symbols());
    }

    @Test
    public void shouldAcceptAllWheelAndSymbolTypes() {
        //Create a machine
        SlotMachine machine = new SlotMachine();

        //Add symbols of the four types
        machine.addSymbol("normal", 1, "red");
        assertTrue(machine.ok());
        machine.addSymbol("ephemeral", 2, "blue");
        assertTrue(machine.ok());
        machine.addSymbol("shy", 3, "green");
        assertTrue(machine.ok());
        machine.addSymbol("special", 4, "yellow");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green", "yellow"},machine.symbols());
        // Add a symbol at a position smaller than 1.
        machine.addSymbol("normal", 0, "black");
        assertTrue(machine.ok());

        // Add a symbol beyond the current number of symbols.
        machine.addSymbol("normal", 10, "white");
        assertTrue(machine.ok());

        //Add wheels of the three types
        machine.addWheel("normal", 1);
        assertTrue(machine.ok());
        machine.addWheel("lefty", 2);
        assertTrue(machine.ok());
        machine.addWheel("rebel", 3);
        assertTrue(machine.ok());

        //Initial setup
        machine.spin(new String[]{"red", "blue", "green"});
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red", "blue", "green"},machine.configuration());

        //Check the behavior of NormalWheel
        machine.spin(1);
        assertTrue(machine.ok());
        assertEquals("blue", machine.configuration()[0]);
        
        //Check the behavior of LeftyWheel
        machine.spin(new String[]{"red", "blue", "green"});
        assertTrue(machine.ok());
        machine.spin(1);
        assertTrue(machine.ok());
        assertEquals(machine.configuration()[0],machine.configuration()[1]);

        //Check the behavior of RebelWheel 
        machine.lock(3);
        assertFalse(machine.ok());
        machine.swap(1, 3);
        assertFalse(machine.ok());
        machine.delWheel(3);
        assertFalse(machine.ok());
        

        //Check the size of the Ephemeral symbol
        EphemeralSymbol ephemeral = new EphemeralSymbol("blue");
        assertEquals(25, ephemeral.getSize());
        ephemeral.spin();
        assertEquals(20, ephemeral.getSize());
        ephemeral.spin();
        assertEquals(15, ephemeral.getSize());
        for (int i = 0; i < 10; i++) {
            ephemeral.spin();
        }
        assertEquals(1, ephemeral.getSize());

        //Check ShySymbol's behavior
        ShySymbol shy = new ShySymbol("green");
        assertTrue(shy.isVisible());
        shy.select();
        assertFalse(shy.isVisible());
        shy.select();
        assertTrue(shy.isVisible());

        //Check the way the Special symbol is represented
        SpecialSymbol special = new SpecialSymbol("yellow");
        assertEquals("square", special.getShape());
    }
}