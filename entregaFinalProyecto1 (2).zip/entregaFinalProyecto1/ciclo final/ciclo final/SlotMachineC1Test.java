import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class SlotMachineC1Test {
   private SlotMachine machine;
   @Before
   public void setUp() {
        machine = new SlotMachine();
   }

   @Test
   public void shouldCreateSlotMachine() {
        assertNotNull(machine);
   }

   @Test
   public void shouldBeOkAfterAddingWheel() {
        machine.addWheel(1);
        assertTrue(machine.ok());
   }

   @Test
   public void shouldAddWheel() {
        machine.addWheel(1);
        assertTrue(machine.ok());
   }

   @Test
   public void shouldDeleteWheel() {
        machine.addWheel(1);
        machine.delWheel(1);
        assertTrue(machine.ok());
   }

   @Test
   public void shouldAddSymbol() {
        machine.addSymbol(1, "red");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red"}, machine.symbols());
   }

   @Test
   public void shouldDeleteSymbol() {
        machine.addSymbol(1, "red");
        machine.delSymbol("red");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{}, machine.symbols());
   }

   @Test
   public void shouldPlaceSymbolOnWheel() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "red");
        assertTrue(machine.ok());
        assertArrayEquals(new String[]{"red"}, machine.configuration());
   }

   @Test
   public void shouldSpinSpecifiedWheel() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "red");
        machine.spin(1);
        assertTrue(machine.ok());
   }

   @Test
   public void shouldSpinAllWheels() {
        machine.addWheel(1);
        machine.addSymbol(1, "red");
        machine.placeSymbol(1, "red");
        machine.spin();
        assertTrue(machine.ok());
   }

   @Test
   public void shouldReturnSymbolsAfterAddingSymbols() {
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        assertArrayEquals(new String[]{"red", "blue"}, machine.symbols());
   }
    
   @Test
   public void shouldCountDistinctSymbolsAfterPlacingSymbols() {
        machine.addWheel(1);
        machine.addWheel(2);    
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        assertEquals(2, machine.distinctSymbols());
   }
    
   @Test
   public void shouldReturnConfigurationAfterPlacingSymbols() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        assertArrayEquals(new String[]{"red", "blue"}, machine.configuration());
   }
    
   @Test
   public void shouldNotHaveJackpotWithDifferentSymbols() {
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "blue");
        machine.placeSymbol(1, "red");
        machine.placeSymbol(2, "blue");
        assertFalse(machine.isJackpot());
   }

   @Test
   public void shouldMakeMachineVisible() {
        machine.makeVisible();
        assertTrue(machine.ok());
   }

   @Test
   public void shouldMakeMachineInvisible() {
        machine.makeVisible();
        machine.makeInvisible();
        assertTrue(machine.ok());
   }
}